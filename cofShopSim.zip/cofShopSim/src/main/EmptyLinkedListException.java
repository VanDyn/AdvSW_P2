package main;

public class EmptyLinkedListException extends Exception
{
	public EmptyLinkedListException() {
		System.out.println("Empty LinkedList");
	}
}
